<?php 


$databaseConnexion= new PDO('mysql:host=127.0.0.1;dbname=car_rental', 'root', '');
?>