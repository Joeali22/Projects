<footer class="footer text-center"> 2021 © Ample Admin brought to you by <a
                    href="https://www.wrappixel.com/">wrappixel.com</a>
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../../assets/admins/plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../../assets/admins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../assets/admins/js/app-style-switcher.js"></script>
    <!--Wave Effects -->
    <script src="../../assets/admins/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../../assets/admins/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../../assets/admins/js/custom.js"></script>
</body>

</html>
